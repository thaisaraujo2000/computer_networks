# importacao das bibliotecas
import socket

# definicao do host e da porta do servidor
HOST = '' # ip do servidor (em branco)
PORT = 8080 # porta do servidor

# cria o socket com IPv4 (AF_INET) usando TCP (SOCK_STREAM)
listen_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# permite que seja possivel reusar o endereco e porta do servidor caso seja encerrado incorretamente
listen_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

# vincula o socket com a porta (faz o "bind" do IP do servidor com a porta)
listen_socket.bind((HOST, PORT))

# "escuta" pedidos na porta do socket do servidor
listen_socket.listen(1)

# imprime que o servidor esta pronto para receber conexoes
print ('Serving HTTP on port %s ...' % PORT)

while True:
    # aguarda por novas conexoes
    client_connection, client_address = listen_socket.accept()

    #Recebendo a requisição do cliente
    request = client_connection.recv(1024) 
    r1 = str(request)
    print(f'r1 = {r1}')

    #Verificando se é um comando válido
    comando = r1[2:5]
    if comando != "GET":
        comando_valido = False
        file = open('400.html','r',encoding="utf-8") 
        http_file = file.read()
        file.close()
        status = 400
    else:
        comando_valido = True

    #Tratamento do caminho da requisição
    request_ok = r1[6:-14]
    print(f'request_ok = {request_ok}')
    if request_ok[0] == "/":
        request_ok = request_ok[1:]

    #Tratamento do caminho da requisição caso seja feita pelo navegador
    if "Host" in request_ok:
        request_ok = request_ok.split(" ")[0]
    print(f'Nova string: {request_ok}')

    #Verificando se é um arquivo válido ou se é o próprio index.html
    if request_ok != "" and comando_valido:
        try:
            file = open(request_ok,'r',encoding="utf-8") 
            http_file = file.read()
            file.close()
            status = 200
        except:
            file = open('404.html','r',encoding="utf-8") 
            http_file = file.read()
            file.close()
            status = 404
    elif request_ok == "" and comando_valido:
        status = 200
        file = open('index.html','r',encoding="utf-8")
        http_file = file.read()
        file.close()

    #Gerando uma resposta
    if status == 200:
        http_response = "HTTP/1.1 200 OK\r\n\r\n"+ http_file
    elif status == 404:
        http_response = "HTTP/1.1 404 Not Found\r\n\r\n"+ http_file
    elif status == 400:
        http_response = "HTTP/1.1 400 Bad Request\r\n\r\n"+ http_file


    # servidor retorna o que foi solicitado pelo cliente (neste caso a resposta e generica)
    client_connection.send(http_response.encode('utf-8'))
    # encerra a conexao
    client_connection.close()

# encerra o socket do servidor
listen_socket.close()